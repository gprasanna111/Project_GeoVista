﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class Program
    {
        static void printUncommon(int[] arr1, int[] arr2, int n1, int n2)
        {
            int i = 0, j = 0, k = 0;
            while (i < n1 && j < n2)
            {
                if (arr1[i] < arr2[j])
                {
                    Console.Write(arr1[i] + " ");
                    i++;
                    k++;
                }
                else if (arr2[j] < arr1[i])
                {
                    Console.Write(arr2[j] + " ");
                    k++;
                    j++;
                }

                else
                {
                    i++;
                    j++;
                }
            }

            while (i < n1)
            {
                Console.Write(arr1[i] + " ");
                i++;
                k++;
            }
            while (j < n2)
            {
                Console.Write(arr2[j] + " ");
                j++;
                k++;
            }
        }
        public static void Main()
        {
            int[] array_A = { 1, 7, 9, 3, 12 };
            int[] array_B = { 12, 5, 57, 1 };

            int n1 = array_A.Length;
            int n2 = array_B.Length;

            printUncommon(array_A, array_B, n1, n2);
        }
    }
}
