﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    class CountNumber
    {
        static void CountRepeating(int[] arr, int size)
        {
            int[] count = new int[size];
            int i;

            Console.Write("Repeated elements are: ");
            for (i = 0; i < size; i++)
            {
                if (count[arr[i]] == 1)
                    Console.Write(arr[i] + " ");
                else
                    count[arr[i]]++;
            }
        }
        public static void Main1()
        {
            int[] array_A = { 1, 3, 75, 75, 1, 7, 3, 1, 75 };
            int arr_size = array_A.Length;
            CountRepeating(array_A, arr_size);
        }
    }
}